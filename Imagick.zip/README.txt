1. profile 적용 및 DPI 변환 명령어
magick convert test\rgb_test1.tif -profile profile\sRGB.icc -profile profile\ICC_Profile_Table.Icc -resample 1200 test\cmyk_test1.tif
