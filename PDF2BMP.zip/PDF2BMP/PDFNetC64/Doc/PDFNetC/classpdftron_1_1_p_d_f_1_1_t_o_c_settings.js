var classpdftron_1_1_p_d_f_1_1_t_o_c_settings =
[
    [ "TOCSettings", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#a244fa337b7b9835bcec5fa41ed33da76", null ],
    [ "~TOCSettings", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#af7d8ecc69172706702264c6d919564f4", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#a723f08e75ed64a955cdec8b21498df15", null ],
    [ "SetCaptionText", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#ab3c2e8d36a626dbcc7ab3b760ec8fd40", null ],
    [ "SetDottedLines", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#a3c899e8eee26115d526d635bbe822d22", null ],
    [ "SetLevelIndentation", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#a51887d54fae2eb8bea2d2517b177741a", null ],
    [ "SetLinks", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#ac951d3883ba698d5b1efbaa8ed00d96f", null ],
    [ "SetTextSizeShrink", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#a3d34faa04ba6b7ee519785a020f92902", null ],
    [ "SetXsl", "classpdftron_1_1_p_d_f_1_1_t_o_c_settings.html#a976b1d817dea59f99cef83436e1a14e4", null ]
];