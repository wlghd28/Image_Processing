var classpdftron_1_1_p_d_f_1_1_verification_options =
[
    [ "SecurityLevel", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a2d42252bc7aded6bfcfde390aa4538ad", [
      [ "e_compatibility_and_archiving", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a2d42252bc7aded6bfcfde390aa4538adad79c749d0504f96f54d076b43846c9e0", null ],
      [ "e_maximum", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a2d42252bc7aded6bfcfde390aa4538ada137f19c9947ef2aa5f9375e3b5d04e10", null ]
    ] ],
    [ "TimeMode", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a47702cd2cf18402d9aee0d00b756d6b5", [
      [ "e_signing", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a47702cd2cf18402d9aee0d00b756d6b5a3e8d2f28fad534be0b053d08b87d193d", null ],
      [ "e_timestamp", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a47702cd2cf18402d9aee0d00b756d6b5a2e216850299ab2e24f18ee587dcfe6ab", null ],
      [ "e_current", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a47702cd2cf18402d9aee0d00b756d6b5afa9965b36d8b16e39d3f05431c1de69b", null ]
    ] ],
    [ "VerificationOptions", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a01256169aa6e6de8651a0bfcbbe66736", null ],
    [ "VerificationOptions", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a392f0093e581ea3939da8a195e5637d1", null ],
    [ "~VerificationOptions", "classpdftron_1_1_p_d_f_1_1_verification_options.html#aa5052d1d5fa814bfef31da297edaaff1", null ],
    [ "VerificationOptions", "classpdftron_1_1_p_d_f_1_1_verification_options.html#abedcbfc65b66b07009c0716964fb2f2c", null ],
    [ "AddTrustedCertificate", "classpdftron_1_1_p_d_f_1_1_verification_options.html#af91524ac94fb1ebee9d8f5517bbab7e5", null ],
    [ "AddTrustedCertificate", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a6b6fec8b18ddb6666e85064aee9cde72", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a39703bceb638772c873f79d6d65abc64", null ],
    [ "EnableDigestVerification", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a2932f6ccbe4c6f8fd192d121391d57c3", null ],
    [ "EnableModificationVerification", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a1e31cddff15eb400261d89aaa2abbdf0", null ],
    [ "EnableTrustVerification", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a903dbf817d447f9c342c8ce24873756f", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a406fd7d46e7bedc90e498881528677cf", null ],
    [ "RemoveTrustedCertificate", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a0851ecf2ce7566ae5d80ae3dfacb6c71", null ],
    [ "RemoveTrustedCertificate", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a2a46ecc41612f5ecd0d0d5686b28b8c1", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_verification_options.html#a14902559c1b5eaae40e5c676439f5313", null ]
];