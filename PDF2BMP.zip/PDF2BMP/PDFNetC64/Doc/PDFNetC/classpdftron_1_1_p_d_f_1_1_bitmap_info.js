var classpdftron_1_1_p_d_f_1_1_bitmap_info =
[
    [ "BitmapInfo", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#aebfb506f37bd82d2ff1144122c3969a5", null ],
    [ "BitmapInfo", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#a487db4b08d4e97bbf9ed9ef693f1d2f5", null ],
    [ "GetBuffer", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#a9c7b4bd1735cbb36722d5dc9e8a05441", null ],
    [ "dpi", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#af1a77d3ee777e73959e73a43a7d859d9", null ],
    [ "height", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#a911a52f8773413d99c838ebad1ddffd4", null ],
    [ "stride", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#a6a1df140e4b7479c5784d9fed6ffb9af", null ],
    [ "width", "classpdftron_1_1_p_d_f_1_1_bitmap_info.html#a2840d659bce9e205d4476cf7d6e4a762", null ]
];