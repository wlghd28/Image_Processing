var classpdftron_1_1_p_d_f_1_1_annots_1_1_text_markup =
[
    [ "TextMarkup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_markup.html#a1616c618c64ec755a75a9aa6054abf91", null ],
    [ "TextMarkup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_markup.html#a648bf37087ad138d7f5dc22abbec554f", null ],
    [ "GetQuadPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_markup.html#a1656529fd02f549e4bcba9cc31db194b", null ],
    [ "GetQuadPointCount", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_markup.html#ae741f586ad33c900e019bc395e2dc8a8", null ],
    [ "SetQuadPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_markup.html#a6d7de25f729f1a275c8052203c7e1ae0", null ]
];