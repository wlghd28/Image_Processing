var classpdftron_1_1_p_d_f_1_1_view_change_collection =
[
    [ "ViewChangeCollection", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a5ae7d10c158a8544eb05a19a351d7aa7", null ],
    [ "~ViewChangeCollection", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a6483fe6641e4bc1ab93b37a4c691a617", null ],
    [ "ViewChangeCollection", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a7c3a855f0c089796ac63a579177872e3", null ],
    [ "ViewChangeCollection", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#ae032163057fb5e55f2563de13fbb3117", null ],
    [ "CreateInternal", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a90aa2531715e92204548f4199bf3bb2f", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a5d70ddcd5ae2539ce91e40922ef1c666", null ],
    [ "GetHandleInternal", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#ae4d756851602cc6ff2579ebd03644ed4", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a352d64ba18c0cd3f6254704d27d37412", null ],
    [ "mp_collection", "classpdftron_1_1_p_d_f_1_1_view_change_collection.html#a6a44753664005196d4580206669ba9dc", null ]
];