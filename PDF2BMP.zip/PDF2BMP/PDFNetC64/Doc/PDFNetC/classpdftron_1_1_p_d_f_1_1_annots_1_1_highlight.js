var classpdftron_1_1_p_d_f_1_1_annots_1_1_highlight =
[
    [ "Highlight", "classpdftron_1_1_p_d_f_1_1_annots_1_1_highlight.html#a99af63a8181770aa9171bb9c85363702", null ],
    [ "Highlight", "classpdftron_1_1_p_d_f_1_1_annots_1_1_highlight.html#a810ffd4baebee81adfbc9466fcbb8ee3", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_highlight.html#ac9789a172e590c538414fcdb5f31e452", null ]
];