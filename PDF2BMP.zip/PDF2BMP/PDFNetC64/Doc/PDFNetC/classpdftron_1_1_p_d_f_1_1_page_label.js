var classpdftron_1_1_p_d_f_1_1_page_label =
[
    [ "Style", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efae", [
      [ "e_decimal", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efaea8a1cf500d4c5fc10d67af55780003561", null ],
      [ "e_roman_uppercase", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efaea68f70fab725c6e32cbee9a2f309bc094", null ],
      [ "e_roman_lowercase", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efaeaf31a4ceda827507f96c89c6efc755797", null ],
      [ "e_alphabetic_uppercase", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efaea84cc5c21bdbbdb60b9dc588f2af2fcc1", null ],
      [ "e_alphabetic_lowercase", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efaead49687c3722d85253d7734c2b8f59a90", null ],
      [ "e_none", "classpdftron_1_1_p_d_f_1_1_page_label.html#a9373b2424581355e78fe11e2a125efaea7cfa14cedf377a858843dbfa945ebc30", null ]
    ] ],
    [ "PageLabel", "classpdftron_1_1_p_d_f_1_1_page_label.html#a4a4258ed0fb20260ba2715366a46ea20", null ],
    [ "PageLabel", "classpdftron_1_1_p_d_f_1_1_page_label.html#af20e4c681f02945a78cc63876000f3d6", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_page_label.html#abf2083548a35b4f96a5c910d9478136c", null ],
    [ "GetFirstPageNum", "classpdftron_1_1_p_d_f_1_1_page_label.html#a4a1f8b5e48ed524b04bf0f3639dbb329", null ],
    [ "GetLabelTitle", "classpdftron_1_1_p_d_f_1_1_page_label.html#ad27292a5b8c26b0b1629081013a1582e", null ],
    [ "GetLastPageNum", "classpdftron_1_1_p_d_f_1_1_page_label.html#a7649a088870695e15a4c8d923e72252e", null ],
    [ "GetPrefix", "classpdftron_1_1_p_d_f_1_1_page_label.html#a07b1500253f8e798c6df18363b785a26", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_page_label.html#ab1dc918548ea53bfc49eaebccb6ea36d", null ],
    [ "GetStart", "classpdftron_1_1_p_d_f_1_1_page_label.html#ac09205adb084dbb3079319ae3a8f44f6", null ],
    [ "GetStyle", "classpdftron_1_1_p_d_f_1_1_page_label.html#a95a7381afb06064bad1bbdeb59b4835d", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_page_label.html#a944086d038dc3fe4ba62d92dfc4f749f", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_page_label.html#a48fb0cfbda07c49a3fbcb78339b69532", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_page_label.html#a1f0a565f8e5213de0b3823ca1e6d31cb", null ],
    [ "SetPrefix", "classpdftron_1_1_p_d_f_1_1_page_label.html#ab098adee1515e8ac1db9d82965b8dc13", null ],
    [ "SetStart", "classpdftron_1_1_p_d_f_1_1_page_label.html#a734eeca146d79f9e98f86611e6773d6e", null ],
    [ "SetStyle", "classpdftron_1_1_p_d_f_1_1_page_label.html#a63f51e1307cd49711c1f5073053067ce", null ]
];