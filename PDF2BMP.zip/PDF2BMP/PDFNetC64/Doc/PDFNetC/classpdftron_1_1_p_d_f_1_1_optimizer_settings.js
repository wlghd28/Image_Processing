var classpdftron_1_1_p_d_f_1_1_optimizer_settings =
[
    [ "OptimizerSettings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a17524200aefd5a1fdad10b31b19a27b5", null ],
    [ "RemoveCustomEntries", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#af42c91398bb5737477127d39eac8948e", null ],
    [ "SetColorImageSettings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a52bdd9061d33e9076315ad3c26f91033", null ],
    [ "SetGrayscaleImageSettings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a4017e0e192a8a0358d6c0a8bfae8f18d", null ],
    [ "SetMonoImageSettings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a57d9458adc6df18b64b9a10fd1f21129", null ],
    [ "SetTextSettings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#ab18bb8c0646a773cf84a214788a5ad47", null ],
    [ "m_color_image_settings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a16779b34e5f7d7a4ae5335c82759289f", null ],
    [ "m_grayscale_image_settings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a6c0cd882ae12b625f73e505602f43046", null ],
    [ "m_mono_image_settings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a6ee089a6cca49dd2c7d0570606510e97", null ],
    [ "m_remove_custom", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#abba808221bb49dc9af0932ef7bf97e06", null ],
    [ "m_text_settings", "classpdftron_1_1_p_d_f_1_1_optimizer_settings.html#a11847b13064a7deff1e591ba9c01f5d8", null ]
];