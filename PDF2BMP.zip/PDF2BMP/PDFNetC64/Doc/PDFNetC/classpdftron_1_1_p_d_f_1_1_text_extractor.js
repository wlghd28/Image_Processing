var classpdftron_1_1_p_d_f_1_1_text_extractor =
[
    [ "Line", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a599445090df0c336b6f0e1d0abca4399", null ],
    [ "Style", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a5d933d0aa873520641fc203fa460507a", null ],
    [ "Word", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a3fef898295ce169f9d8be555f03e12dc", null ],
    [ "ProcessingFlags", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a45e14d9b74a6454c8f0462c4ea546be5", [
      [ "e_no_ligature_exp", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a45e14d9b74a6454c8f0462c4ea546be5aae5ced0619bbacd34ea93c52a9956f5f", null ],
      [ "e_no_dup_remove", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a45e14d9b74a6454c8f0462c4ea546be5a41b831a472c59f7c7762dcaa54985aee", null ],
      [ "e_punct_break", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a45e14d9b74a6454c8f0462c4ea546be5a5bce495cc4df0d61819414f31e02c766", null ],
      [ "e_remove_hidden_text", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a45e14d9b74a6454c8f0462c4ea546be5ae4e1aed8af08108f5780b4dfb8d718c0", null ],
      [ "e_no_invisible_text", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a45e14d9b74a6454c8f0462c4ea546be5a842376e7adea050aa1813486c1f92d42", null ]
    ] ],
    [ "XMLOutputFlags", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a598b2c4c951594ec2e122eeccb2e5160", [
      [ "e_words_as_elements", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a598b2c4c951594ec2e122eeccb2e5160a849e2f1aa264ced1670f9485e1505ff0", null ],
      [ "e_output_bbox", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a598b2c4c951594ec2e122eeccb2e5160af9b6191c89dbefbbd5a1f0a738527c51", null ],
      [ "e_output_style_info", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a598b2c4c951594ec2e122eeccb2e5160a805be6fbe93ddd3e4c4f4df679ebbce6", null ]
    ] ],
    [ "TextExtractor", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a4bdb2c42bd126842dd586b8ccc8c3692", null ],
    [ "~TextExtractor", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#aba48a18da99355ad8c95640253a01e94", null ],
    [ "Begin", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a98e3e4881328d9c48e7e57d6200da18f", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a6413acfdcc7fb15ad6d9e85064e7284e", null ],
    [ "GetAsText", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#af9ffcdcc717a5c78658d629d49f42d78", null ],
    [ "GetAsText", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a7f4b22b9457f5c9d085336d467ae495b", null ],
    [ "GetAsXML", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a5b574635661b598e75748662309fa2b2", null ],
    [ "GetAsXML", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a2285dbbb2fe355a8d45e532759eb5066", null ],
    [ "GetFirstLine", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a241f16154117b86f90e1c325656b9513", null ],
    [ "GetNumLines", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#ae64d9f086673b59e306b4c4c85d0872a", null ],
    [ "GetRightToLeftLanguage", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a2b977384de164447775568c8b16719fc", null ],
    [ "GetTextUnderAnnot", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a6da304d82307150a5eff1b596e3b9c73", null ],
    [ "GetTextUnderAnnot", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a9fc4a981405c1102ee9489303bf66dd5", null ],
    [ "GetWordCount", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#a96dd965b673295c15e3e1677b8932d09", null ],
    [ "SetRightToLeftLanguage", "classpdftron_1_1_p_d_f_1_1_text_extractor.html#aeca0d0263eb9547c8cc29a866f352d75", null ]
];