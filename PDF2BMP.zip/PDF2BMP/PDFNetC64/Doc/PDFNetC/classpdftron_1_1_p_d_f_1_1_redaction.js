var classpdftron_1_1_p_d_f_1_1_redaction =
[
    [ "Redaction", "classpdftron_1_1_p_d_f_1_1_redaction.html#a245e276e9cd330f010c50c929a81044c", null ],
    [ "~Redaction", "classpdftron_1_1_p_d_f_1_1_redaction.html#af09f264520caf3dbeed8f17de8f6b0ee", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_redaction.html#a8ea3ff767065ebd9ee8803088baf43c4", null ]
];