var classpdftron_1_1_p_d_f_1_1_word =
[
    [ "Word", "classpdftron_1_1_p_d_f_1_1_word.html#a2653ccaae5eaa9429ba24597e35e585f", null ],
    [ "GetBBox", "classpdftron_1_1_p_d_f_1_1_word.html#ab4e1b12efdd9929467899b9638f3bf9e", null ],
    [ "GetBBox", "classpdftron_1_1_p_d_f_1_1_word.html#a8bcc0eacffedd6ace995dbb8d2517029", null ],
    [ "GetCharStyle", "classpdftron_1_1_p_d_f_1_1_word.html#a1648f8142085ed25b69bd5671b830a11", null ],
    [ "GetCurrentNum", "classpdftron_1_1_p_d_f_1_1_word.html#ae9483ee1c33e2902460b2148b1d802f7", null ],
    [ "GetGlyphQuad", "classpdftron_1_1_p_d_f_1_1_word.html#a5690375517709a4801c91455e28af3a8", null ],
    [ "GetGlyphQuad", "classpdftron_1_1_p_d_f_1_1_word.html#a49e5a9a501240f0576ea6ee91791485b", null ],
    [ "GetNextWord", "classpdftron_1_1_p_d_f_1_1_word.html#aec10d791d54bab16ea38132b16171652", null ],
    [ "GetNumGlyphs", "classpdftron_1_1_p_d_f_1_1_word.html#ad466385646fb2eaa8f99e45fda94ef74", null ],
    [ "GetQuad", "classpdftron_1_1_p_d_f_1_1_word.html#a2da449b72856eb8cef750f76af7124ff", null ],
    [ "GetQuad", "classpdftron_1_1_p_d_f_1_1_word.html#a4c7587b535d9bd30d5ebb28c34f46e5e", null ],
    [ "GetString", "classpdftron_1_1_p_d_f_1_1_word.html#aa487790d982b74307c2dadfb879532a9", null ],
    [ "GetStringLen", "classpdftron_1_1_p_d_f_1_1_word.html#aa0389e2c41aed8831341187d7548b87d", null ],
    [ "GetStyle", "classpdftron_1_1_p_d_f_1_1_word.html#a2cb84057daca5def69f96e02c4403794", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_word.html#a45a66c38571b9b60801f72e60bcbc337", null ],
    [ "operator!=", "classpdftron_1_1_p_d_f_1_1_word.html#a54e20ad23e8f4fcb154499c2c5beea95", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_word.html#a3588c93bcca2d6d71fcb134fb7afe45d", null ]
];