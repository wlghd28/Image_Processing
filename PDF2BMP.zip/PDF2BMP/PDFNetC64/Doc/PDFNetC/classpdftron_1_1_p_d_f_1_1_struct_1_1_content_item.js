var classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item =
[
    [ "Type", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#aff725b37da8ea2b1083ee298419e6fad", [
      [ "e_MCR", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#aff725b37da8ea2b1083ee298419e6fadaa38627f6608ae6b9941fa3c836479a39", null ],
      [ "e_MCID", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#aff725b37da8ea2b1083ee298419e6fadafa3086d9395455a21d1729e43636c5e5", null ],
      [ "e_OBJR", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#aff725b37da8ea2b1083ee298419e6fadadd6a0d0d37eb0d5deb93a0819d8183b1", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#aff725b37da8ea2b1083ee298419e6fada72e9a3b88d6081c16dabd43a903f610a", null ]
    ] ],
    [ "ContentItem", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#adecaad6881674a6e2d8f7a8aee53b442", null ],
    [ "GetContainingStm", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#a01713679e71f396cf95dca0240bd0d5b", null ],
    [ "GetMCID", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#ad7762194daad0ebcb11a1a2de7c08831", null ],
    [ "GetPage", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#a1fbce36bdec2e04c3fb4a4fdecb71d96", null ],
    [ "GetParent", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#aad59d0e2b9da98cf935996a134534972", null ],
    [ "GetRefObj", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#ac8e896949fc7967a9c618c51026bac15", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#a23897fff454b0c7b30cdf7eda23b62c9", null ],
    [ "GetStmOwner", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#af4ce64864f63ed5478c68a5982fee285", null ],
    [ "GetType", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#a3c8df4773a0c127b63dedc979d010b5b", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_struct_1_1_content_item.html#a986e4d3f9940daa7c04f78cf725f56f5", null ]
];