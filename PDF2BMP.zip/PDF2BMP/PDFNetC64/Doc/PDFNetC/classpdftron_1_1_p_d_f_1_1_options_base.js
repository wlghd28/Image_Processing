var classpdftron_1_1_p_d_f_1_1_options_base =
[
    [ "ColorPtFromNumber", "classpdftron_1_1_p_d_f_1_1_options_base.html#a86f3f583701be3c59e4fa3194164945d", null ],
    [ "ColorPtToNumber", "classpdftron_1_1_p_d_f_1_1_options_base.html#a28b033add8e0e2e042020e9aed02fdec", null ],
    [ "GetArray", "classpdftron_1_1_p_d_f_1_1_options_base.html#adf707a825fbe77d1f0b17dd822e53a68", null ],
    [ "InsertRectCollection", "classpdftron_1_1_p_d_f_1_1_options_base.html#a29a94ae9f4209ff9f4132b05c822fbc5", null ],
    [ "PushBackBool", "classpdftron_1_1_p_d_f_1_1_options_base.html#a1863edcbcb34043ba7171e86896c5f79", null ],
    [ "PushBackNumber", "classpdftron_1_1_p_d_f_1_1_options_base.html#ab4eac977e91a74a7ff8969517336f8af", null ],
    [ "PushBackRect", "classpdftron_1_1_p_d_f_1_1_options_base.html#a70c75aa60b3ea62ec76cc1e7e50030a4", null ],
    [ "PushBackText", "classpdftron_1_1_p_d_f_1_1_options_base.html#ace57ad8f93ff0b0d20b1333a520087ff", null ],
    [ "PutBool", "classpdftron_1_1_p_d_f_1_1_options_base.html#a853054a0e541fb0d757d14601808a796", null ],
    [ "PutNumber", "classpdftron_1_1_p_d_f_1_1_options_base.html#a438b59fc88bea66456672225dc02bb27", null ],
    [ "PutRect", "classpdftron_1_1_p_d_f_1_1_options_base.html#abcb942f55bc801953ebf6e0181f16c02", null ],
    [ "PutText", "classpdftron_1_1_p_d_f_1_1_options_base.html#ab4aa59e3e4bdccdb59f731df84e28767", null ],
    [ "RectFromArray", "classpdftron_1_1_p_d_f_1_1_options_base.html#a36a4ac874990e19567eda956354aa87e", null ],
    [ "RectFromArray", "classpdftron_1_1_p_d_f_1_1_options_base.html#a5245cf30322aa77bef16605f7a4a40c0", null ]
];