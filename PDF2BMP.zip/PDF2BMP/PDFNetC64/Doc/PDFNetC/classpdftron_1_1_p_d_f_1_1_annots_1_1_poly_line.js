var classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line =
[
    [ "IntentType", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af515d8825621c24cf1ad648c391235f8", [
      [ "e_PolygonCloud", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af515d8825621c24cf1ad648c391235f8a113260615d87d135d70a452983f83239", null ],
      [ "e_PolyLineDimension", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af515d8825621c24cf1ad648c391235f8a3a6569df1f5cd20874c3630f6abb8f8a", null ],
      [ "e_PolygonDimension", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af515d8825621c24cf1ad648c391235f8aac09c947aaf8a4c190287364b1daba43", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af515d8825621c24cf1ad648c391235f8adcded354cd7e95a04363611442443d56", null ]
    ] ],
    [ "PolyLine", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a6f9fc07c13a6ff7f45cd8a111a8ada64", null ],
    [ "PolyLine", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a55f0ab2b8a43aec705020a18523385ba", null ],
    [ "PolyLine", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a1ae00324a8d81ac4c9eaa7e723c26962", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a237bcb322a2da3dd8542c67a5b3b098a", null ],
    [ "GetIntentName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a9bfc41da1c73a29836dff7f5a5c406ca", null ],
    [ "GetVertex", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af9aa59ba2f26914cd602a9c7ccd39db1", null ],
    [ "GetVertexCount", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#af14cb9677d1254c4494146862c152438", null ],
    [ "SetIntentName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a94c0bbf2f8024b36c0d43aac9e2b6cce", null ],
    [ "SetVertex", "classpdftron_1_1_p_d_f_1_1_annots_1_1_poly_line.html#a13c4fae02d354eb342819dca1e098ad1", null ]
];