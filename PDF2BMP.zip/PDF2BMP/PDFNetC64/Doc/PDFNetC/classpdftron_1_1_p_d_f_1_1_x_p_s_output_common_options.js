var classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options =
[
    [ "OverprintPreviewMode", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#af85dea6e81b2a8d6264e94430e5c7ef9", [
      [ "e_op_off", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#af85dea6e81b2a8d6264e94430e5c7ef9a83abe225014180194d22d089b006077d", null ],
      [ "e_op_on", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#af85dea6e81b2a8d6264e94430e5c7ef9a2fe9afd3aa1198a5b903dbf49d9f75ec", null ],
      [ "e_op_pdfx_on", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#af85dea6e81b2a8d6264e94430e5c7ef9aca14784dec98a5d7f775f583ce418a40", null ]
    ] ],
    [ "XPSOutputCommonOptions", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#a34eb3a3aedda8260648819b992d25063", null ],
    [ "GenerateURLLinks", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#a57120af6ffb63e7f529af80bb60822fc", null ],
    [ "SetDPI", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#a37e4edb922f1e4dd917313e16931b090", null ],
    [ "SetOverprint", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#af53b2d3f0b6587b05f083ca1d588ef42", null ],
    [ "SetPrintMode", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#a7b6abdd9b5c3bb6884ad7c391d8eb0b3", null ],
    [ "SetRenderPages", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#a3a513d9992de8a0bfb038194c8f5939b", null ],
    [ "SetThickenLines", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#ac3f208623fcbc0380df8d0083a5d82d9", null ],
    [ "Convert", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#a2d2f4f747b784412804ac6e44390cf1f", null ],
    [ "m_obj", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#acd07b0dc5362b0f09f01ac747dfa3945", null ],
    [ "m_objset", "classpdftron_1_1_p_d_f_1_1_x_p_s_output_common_options.html#af85a95ffe95b1d2b789e4304b9e722d5", null ]
];