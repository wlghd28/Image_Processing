var classpdftron_1_1_p_d_f_1_1_element_reader =
[
    [ "ElementReader", "classpdftron_1_1_p_d_f_1_1_element_reader.html#ae86aceca2ea12ed2a324fea44dc669f4", null ],
    [ "~ElementReader", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a3c9fc3af562bacdc4a97ed8e3a214ad8", null ],
    [ "AppendResource", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a6affbfbe481a959a51d640173142f5e1", null ],
    [ "Begin", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a9a7c2a2b1536c0363d851a1a194d0d4b", null ],
    [ "Begin", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a5547d35de3bf3b240c54d4a91648f5c7", null ],
    [ "ClearChangeList", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a0b6b8b376baa01201cb643379b732084", null ],
    [ "Current", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a4d197c23148a3d6d4fb61b4fe7872a4c", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a3bf193932fc3bb5285e2e4b7cc9fb3a5", null ],
    [ "End", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a031c28e5ea3c235e295e582573fbc83c", null ],
    [ "FormBegin", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a01fc3a7408bc5aad8e8b100ffd94a9fa", null ],
    [ "GetChangesIterator", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a8a2bcac84b9d41e10d2a47756f1aecce", null ],
    [ "GetColorSpace", "classpdftron_1_1_p_d_f_1_1_element_reader.html#ab604b1dc26364e52c2c3b35c1efe668c", null ],
    [ "GetExtGState", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a8a2c22b0848c5a2ab676de119907beb0", null ],
    [ "GetFont", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a66433e69cd178679e19bf271b46b20e5", null ],
    [ "GetPattern", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a50c34ae3f7fb53ce8951920d54e3f151", null ],
    [ "GetShading", "classpdftron_1_1_p_d_f_1_1_element_reader.html#ad26fd2296c86281fdea8592476ba774b", null ],
    [ "GetXObject", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a4f9a1b89d1c83e8bdbaf95f7d7adfcf2", null ],
    [ "IsChanged", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a03068d8230f0bed4c02e8a809f85d75a", null ],
    [ "Next", "classpdftron_1_1_p_d_f_1_1_element_reader.html#aa37e38453da96895a918eec52e5765b6", null ],
    [ "PatternBegin", "classpdftron_1_1_p_d_f_1_1_element_reader.html#a3a09f7e928eb34ef005d2fa25a17b1d6", null ],
    [ "Type3FontBegin", "classpdftron_1_1_p_d_f_1_1_element_reader.html#ad4cd53966a00281382c88c7f4f9f4ba0", null ]
];