var classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options =
[
    [ "HTMLOutputOptions", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a03362676c60f3c418dd14625b68eb3ce", null ],
    [ "SetDPI", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a66794e205cd76c73be933cd8c3a49a89", null ],
    [ "SetExternalLinks", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a9dd3b7b98ed003143e66cbc0b381cdb0", null ],
    [ "SetInternalLinks", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#abe99552dba70b39825ecfaffee43dba9", null ],
    [ "SetJPGQuality", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a27274a83880bbcb17b92a16a4062afd5", null ],
    [ "SetMaximumImagePixels", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a974095533be3e8143510ec6a6237e4ab", null ],
    [ "SetPreferJPG", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#ae197408750593cd8dd6991e909ac31fa", null ],
    [ "SetReflow", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aa81ea13186c15cfe9018242a59d1904b", null ],
    [ "SetReportFile", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aadb1105d3a2b26db344f96ecf9698dae", null ],
    [ "SetScale", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a093d38248f45e330a632d37d1d57b000", null ],
    [ "SetSimplifyText", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a0596aca2fc90bf9a3ded3f7daeb84215", null ],
    [ "Convert", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a2d2f4f747b784412804ac6e44390cf1f", null ],
    [ "m_obj", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a9abe15dc9dceb990e1d62bcaf395d296", null ],
    [ "m_objset", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aeeea3a22293186735d1255da19c1183b", null ]
];