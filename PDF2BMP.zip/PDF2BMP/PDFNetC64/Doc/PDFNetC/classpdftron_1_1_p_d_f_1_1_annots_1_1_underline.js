var classpdftron_1_1_p_d_f_1_1_annots_1_1_underline =
[
    [ "Underline", "classpdftron_1_1_p_d_f_1_1_annots_1_1_underline.html#ac1e867303c80fe6cd2c8eb395cc7067d", null ],
    [ "Underline", "classpdftron_1_1_p_d_f_1_1_annots_1_1_underline.html#aea8f23adf3191c418ab6707bfab7cd2e", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_underline.html#a3bf94a2c1cddcb0df6dc275285c400d5", null ]
];