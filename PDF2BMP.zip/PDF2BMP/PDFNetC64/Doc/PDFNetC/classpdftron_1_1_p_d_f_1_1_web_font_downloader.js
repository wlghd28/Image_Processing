var classpdftron_1_1_p_d_f_1_1_web_font_downloader =
[
    [ "ClearCache", "classpdftron_1_1_p_d_f_1_1_web_font_downloader.html#afbcb206e9ff54d655fbef087227d8e89", null ],
    [ "DisableDownloads", "classpdftron_1_1_p_d_f_1_1_web_font_downloader.html#aadf023b2ce5a75d6f0c28bcc16ea660b", null ],
    [ "EnableDownloads", "classpdftron_1_1_p_d_f_1_1_web_font_downloader.html#a7f74e023e970955e9094ec06539fa125", null ],
    [ "IsAvailable", "classpdftron_1_1_p_d_f_1_1_web_font_downloader.html#a6d63d8daedc0795701df2151ef8e6ba4", null ],
    [ "PreCacheAsync", "classpdftron_1_1_p_d_f_1_1_web_font_downloader.html#a9481bc8b509385e26b53c8c8c0b5362e", null ],
    [ "SetCustomWebFontURL", "classpdftron_1_1_p_d_f_1_1_web_font_downloader.html#a699b0691795c1d7e5f45a2117376a197", null ]
];