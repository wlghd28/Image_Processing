var classpdftron_1_1_p_d_f_1_1_annots_1_1_watermark =
[
    [ "Watermark", "classpdftron_1_1_p_d_f_1_1_annots_1_1_watermark.html#a41ab8f4319a49c9f0231c02c4f25bbcb", null ],
    [ "Watermark", "classpdftron_1_1_p_d_f_1_1_annots_1_1_watermark.html#ab31f6adbe81c3808ca4a365aba3d4c84", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_watermark.html#a4839420ba88d197032fd800bb0129ae8", null ]
];