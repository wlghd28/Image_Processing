var classpdftron_1_1_filters_1_1_memory_filter =
[
    [ "MemoryFilter", "classpdftron_1_1_filters_1_1_memory_filter.html#ad3d8701cffd560cc582582c293b2d1e9", null ],
    [ "GetBuffer", "classpdftron_1_1_filters_1_1_memory_filter.html#a4dd86549003e02786ffdf1acd7bc80c4", null ],
    [ "SetAsInputFilter", "classpdftron_1_1_filters_1_1_memory_filter.html#afd7ce099930f6fc5ea49009626eff164", null ]
];