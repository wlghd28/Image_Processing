var classpdftron_1_1_p_d_f_1_1_external_annot_manager =
[
    [ "ExternalAnnotManager", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a1f2aa97809f502737703b3306e293095", null ],
    [ "ExternalAnnotManager", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#ad9270d23b0fa67d568e283b4acc94258", null ],
    [ "ExternalAnnotManager", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a664c646c5f3a8716fe831e25e57e2ba2", null ],
    [ "~ExternalAnnotManager", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a5d026f40b8c1751117afeed7abeb80cd", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#addb654b42d951ddb802733d9ff0827d7", null ],
    [ "GetLastXFDF", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a4cef8e14fc7bfc9fd9b33b76c513fbb8", null ],
    [ "GetNextRedoInfo", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a47dc5eac14918cd42d4954d90e5132b5", null ],
    [ "GetNextUndoInfo", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a56b3ffa8189fd67d5fa2e0270d40af1b", null ],
    [ "MergeXFDF", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a28cc5c1f2ecd4393f01c215e99cd72bf", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a7083c8aebd88c8dddf438d6a671ae514", null ],
    [ "Redo", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a0c268b392790765d61afd2499dd8252b", null ],
    [ "TakeSnapshot", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a4c61ea84e985dd7a9be2393c7ebda84b", null ],
    [ "Undo", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#ac61caaf87e6a7f989c9e6bb533b8f4de", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_external_annot_manager.html#a9c3b8feaad80b59781349f91df2a95cc", null ]
];