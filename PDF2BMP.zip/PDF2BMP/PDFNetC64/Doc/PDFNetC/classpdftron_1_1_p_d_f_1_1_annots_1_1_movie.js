var classpdftron_1_1_p_d_f_1_1_annots_1_1_movie =
[
    [ "Movie", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#a7146a020100650bec651d04f8eef6900", null ],
    [ "Movie", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#a07621d1c4f1c3f0f1b0e47bbbfd694b4", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#a580c5f152101d6987ba480059b73a734", null ],
    [ "GetTitle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#a2c83ccff95025ca6c5dbf48fdd8271cd", null ],
    [ "IsToBePlayed", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#a237e21ea859bdbada2b92be0cf8883c6", null ],
    [ "SetTitle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#aaa847500b6524b2dd01a90f5a42efc41", null ],
    [ "SetToBePlayed", "classpdftron_1_1_p_d_f_1_1_annots_1_1_movie.html#a8f21e605f5ef46f247b1ad264dfacc81", null ]
];