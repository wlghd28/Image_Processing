var classpdftron_1_1_common_1_1_iterator =
[
    [ "Iterator", "classpdftron_1_1_common_1_1_iterator.html#a486178a9247a81319675f40d54d457b2", null ],
    [ "~Iterator", "classpdftron_1_1_common_1_1_iterator.html#a1a68ed37d765caac89eb0159216d6b1e", null ],
    [ "Iterator", "classpdftron_1_1_common_1_1_iterator.html#ab0020dedd40e4b1529d82cb0198f6f65", null ],
    [ "Current", "classpdftron_1_1_common_1_1_iterator.html#acf059d23012a1ef656c9a9b76b206c15", null ],
    [ "Destroy", "classpdftron_1_1_common_1_1_iterator.html#ae32fb177b47235140033414b711c3b02", null ],
    [ "HasNext", "classpdftron_1_1_common_1_1_iterator.html#af06c8f925bff9e573145c16188f0871c", null ],
    [ "Next", "classpdftron_1_1_common_1_1_iterator.html#a8392a7e07a4886d5b5b29c0fbe42b926", null ],
    [ "operator=", "classpdftron_1_1_common_1_1_iterator.html#a66f40cb441469dc1f301ca7facf41881", null ]
];