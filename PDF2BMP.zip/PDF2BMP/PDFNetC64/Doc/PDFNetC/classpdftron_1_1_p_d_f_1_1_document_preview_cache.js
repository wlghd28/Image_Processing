var classpdftron_1_1_p_d_f_1_1_document_preview_cache =
[
    [ "PreviewHandler", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a687cc9abd2cf3a8ac11ac067b9ca908e", null ],
    [ "preview_result", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a76cf2229bd792213b5cbf0d7c2696a05", [
      [ "e_failure", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a76cf2229bd792213b5cbf0d7c2696a05ade9e6870c7b3ff1c690a9caeb215b8a1", null ],
      [ "e_success", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a76cf2229bd792213b5cbf0d7c2696a05aaa019c9fb0272eafe68191c9efc59fef", null ],
      [ "e_security_error", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a76cf2229bd792213b5cbf0d7c2696a05a0c643e01806ba45a38769821f85df521", null ],
      [ "e_cancel", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a76cf2229bd792213b5cbf0d7c2696a05a978f53e8e5a71e801d56af5e8390141f", null ],
      [ "e_package_error", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a76cf2229bd792213b5cbf0d7c2696a05a0a550bbb480a8d1445df507215e08906", null ]
    ] ],
    [ "CancelAllRequests", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a1ce931cd8de5840db25d1de9784ee834", null ],
    [ "CancelRequest", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a60bd4adce46ec80c4ad5e65e1134987a", null ],
    [ "ClearCache", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a3fdea1f07b36b77cc163ed35dd8489fb", null ],
    [ "GetBitmapWithPath", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#adeea897cf71bd38a9dce74b70f2c92d2", null ],
    [ "Initialize", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#ad73e6df919459f4b10351414889e4c78", null ],
    [ "IrrelevantChangeMade", "classpdftron_1_1_p_d_f_1_1_document_preview_cache.html#a0a2252a017d06fbd9613950497f1ffca", null ]
];