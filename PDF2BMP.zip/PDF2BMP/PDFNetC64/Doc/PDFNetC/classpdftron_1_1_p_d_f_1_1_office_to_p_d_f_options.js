var classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options =
[
    [ "OfficeToPDFOptions", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#aad578c077ed4b958562daf8049f007d1", null ],
    [ "~OfficeToPDFOptions", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a4c792055b51e21bc60851f37b9dfd888", null ],
    [ "GetExcelDefaultCellBorderWidth", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a3087478a84a60f705bd9b5c99b40af8b", null ],
    [ "GetLayoutResourcesPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a29780a2d8856842bed8347fd40178269", null ],
    [ "GetResourceDocPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a0d6dfae6cbccf660bbe6469d8b598573", null ],
    [ "GetSmartSubstitutionPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a9b5dbcd5d4caa1e50a343aad25e803ee", null ],
    [ "SetExcelDefaultCellBorderWidth", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a99ddee2ddf200d61ba37728aef97024d", null ],
    [ "SetLayoutResourcesPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a8f37742ff66cc472078e38ee7b38e424", null ],
    [ "SetResourceDocPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#aaf76ca0804a15de9932e446d74f34ee6", null ],
    [ "SetSmartSubstitutionPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a0adcab5382d14b50e546bcc1bd8ab8df", null ]
];