var classpdftron_1_1_p_d_f_1_1_disallowed_change =
[
    [ "Type", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205", [
      [ "e_form_filled", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205a52bad4ebebcc42116ad0e71ab28560f9", null ],
      [ "e_digital_signature_signed", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205aec7f0f65117354a8552fb49fcbfe307d", null ],
      [ "e_page_template_instantiated", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205ae856ade0ff5406b7f10f2492caa45316", null ],
      [ "e_annotation_created_or_updated_or_deleted", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205a905db89ba861460864ffa865e6f89490", null ],
      [ "e_other", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205a9c271a23fffaa1b8ee6ba68ac05e663b", null ],
      [ "e_unknown", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#af09dc25e31302f755060256a89a02205a3e28401055a0a6195bb6272c85e8cfc9", null ]
    ] ],
    [ "DisallowedChange", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#aa9865ab684d564df8ee5756d7a3071fc", null ],
    [ "DisallowedChange", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#abf74c1ceaf0f08af73717a30cf41d71b", null ],
    [ "DisallowedChange", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#ac82ec19fd2c6be29404b58d9a3f8ca34", null ],
    [ "~DisallowedChange", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#a36b653c779f75cfa147fba6f70cbe876", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#a3bbdafbe5a8efc68de10b2f834fc00e3", null ],
    [ "GetObjNum", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#a1369996880aec58fc6f24b3348f4bafb", null ],
    [ "GetType", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#a5abf504552a56b061b9dfa30b493fa71", null ],
    [ "GetTypeAsString", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#a926de4783cd3a6c90f4152900a1e37b9", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#ab983b5e0426b26a45fc74a64e34aa041", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_disallowed_change.html#ae0df8f38f42dc80af17b23c05c8a0931", null ]
];