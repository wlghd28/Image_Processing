var classpdftron_1_1_p_d_f_1_1_digest_algorithm =
[
    [ "Type", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083d", [
      [ "e_SHA1", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083da9d14c988f4866dbe16526410a89ad76e", null ],
      [ "e_SHA256", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083da5815008f6cf778a51108c3bde369f6ef", null ],
      [ "e_SHA384", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083da3e444613ea43c370de7814ec0db73b1f", null ],
      [ "e_SHA512", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083da2e75e293819495ca24e96fd25ebad3cd", null ],
      [ "e_RIPEMD160", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083da924f97275c309d8ab42f24b59bd83a82", null ],
      [ "e_unknown_digest_algorithm", "classpdftron_1_1_p_d_f_1_1_digest_algorithm.html#a0708c342413601a7bda156150ac0083daacd3941fb6a3185765a3246d895f860a", null ]
    ] ]
];