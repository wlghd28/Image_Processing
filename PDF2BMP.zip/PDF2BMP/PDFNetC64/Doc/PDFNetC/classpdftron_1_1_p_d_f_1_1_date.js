var classpdftron_1_1_p_d_f_1_1_date =
[
    [ "Date", "classpdftron_1_1_p_d_f_1_1_date.html#ad597b66bcd29b2bb2ee0b9d12f7138d1", null ],
    [ "Date", "classpdftron_1_1_p_d_f_1_1_date.html#a6b8c320e1449e029de721b685567e70b", null ],
    [ "Date", "classpdftron_1_1_p_d_f_1_1_date.html#ada45c3a9846907f2fa63c87aa0ed5766", null ],
    [ "Date", "classpdftron_1_1_p_d_f_1_1_date.html#a5332e4e4abfc984dd52b34955b8e7195", null ],
    [ "Attach", "classpdftron_1_1_p_d_f_1_1_date.html#a234a49f2e09902c1b5d07fba2c31f9cd", null ],
    [ "GetDay", "classpdftron_1_1_p_d_f_1_1_date.html#a718b33e06766211303e793bad4926cb7", null ],
    [ "GetHour", "classpdftron_1_1_p_d_f_1_1_date.html#a2065ab8815e4ec2085227dd2d4212cc9", null ],
    [ "GetMinute", "classpdftron_1_1_p_d_f_1_1_date.html#a1af5409be4636f44acbdf46ce24e490d", null ],
    [ "GetMonth", "classpdftron_1_1_p_d_f_1_1_date.html#a49c10f257b58a20a34fffa45218b0db7", null ],
    [ "GetSecond", "classpdftron_1_1_p_d_f_1_1_date.html#aa1eaf5cd71a998afff8f72d9dd2cc39a", null ],
    [ "GetUT", "classpdftron_1_1_p_d_f_1_1_date.html#af4322513e34adc6dd5db1dc176a68306", null ],
    [ "GetUTHour", "classpdftron_1_1_p_d_f_1_1_date.html#a842d018d21a90354fbac4899350c04f9", null ],
    [ "GetUTMin", "classpdftron_1_1_p_d_f_1_1_date.html#a2279c504fcf167c386c0b78019e58bfe", null ],
    [ "GetYear", "classpdftron_1_1_p_d_f_1_1_date.html#a6e99a588a3f1a8833bd3af8ebd5dbdd3", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_date.html#a526ef610c2709ad26eeddc60ce695a17", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_date.html#ad14e9a760292d7862671f7dcb24a4d7e", null ],
    [ "SetCurrentTime", "classpdftron_1_1_p_d_f_1_1_date.html#a34077f7487c8bc3f5c0a6ee32e0225ad", null ],
    [ "Update", "classpdftron_1_1_p_d_f_1_1_date.html#a724eb13dcbdc617138d297e1aafd6c9d", null ]
];