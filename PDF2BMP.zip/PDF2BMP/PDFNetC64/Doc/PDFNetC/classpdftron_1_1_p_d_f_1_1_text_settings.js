var classpdftron_1_1_p_d_f_1_1_text_settings =
[
    [ "TextSettings", "classpdftron_1_1_p_d_f_1_1_text_settings.html#a2e143a24670c93d77a1417ae68c33f9f", null ],
    [ "EmbedFonts", "classpdftron_1_1_p_d_f_1_1_text_settings.html#a22d8c023507bd833c15df84c94780f6a", null ],
    [ "SubsetFonts", "classpdftron_1_1_p_d_f_1_1_text_settings.html#ad8ac8b17a731abc54e8904f8193ceacf", null ]
];