var classpdftron_1_1_p_d_f_1_1_selection =
[
    [ "GetAsHtml", "classpdftron_1_1_p_d_f_1_1_selection.html#ae9bfeec2169d8eb9ff84fe69c5d4d362", null ],
    [ "GetAsUnicode", "classpdftron_1_1_p_d_f_1_1_selection.html#a21767b5cb161bf2fc28198f73b90ef67", null ],
    [ "GetAsUnicode", "classpdftron_1_1_p_d_f_1_1_selection.html#ab63c19c56e7838fe53d89ef8a36624a8", null ],
    [ "GetPageNum", "classpdftron_1_1_p_d_f_1_1_selection.html#a366e46290340e6e6ab47fb20f660fa55", null ],
    [ "GetQuads", "classpdftron_1_1_p_d_f_1_1_selection.html#a7715dd0005a687956bdbf71eb25e167b", null ],
    [ "GetQuads", "classpdftron_1_1_p_d_f_1_1_selection.html#aaf86aebc6b6f5016f74ade316cc7befc", null ],
    [ "PDFView", "classpdftron_1_1_p_d_f_1_1_selection.html#a63c5a1ce6c86024bd3a92bd8b1da2f7a", null ],
    [ "PDFViewCtrl", "classpdftron_1_1_p_d_f_1_1_selection.html#a6fae7ebe228fbfb4432446e4ed1f9a36", null ]
];