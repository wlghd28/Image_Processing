var classpdftron_1_1_p_d_f_net_1_1_security_descriptor =
[
    [ "GetCreateFunct", "classpdftron_1_1_p_d_f_net_1_1_security_descriptor.html#ab71de2130d8cb174d371fe5552d8898d", null ],
    [ "GetGuiName", "classpdftron_1_1_p_d_f_net_1_1_security_descriptor.html#a9c317dcd4cd3b526658e6a4356244f53", null ],
    [ "GetName", "classpdftron_1_1_p_d_f_net_1_1_security_descriptor.html#a7d1267fd974666623e9e8e0ad2febe2b", null ]
];