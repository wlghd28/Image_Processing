var classpdftron_1_1_p_d_f_1_1_annots_1_1_line =
[
    [ "CapPos", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a1a95cbc0e65199704e9669cdf71a659c", [
      [ "e_Inline", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a1a95cbc0e65199704e9669cdf71a659cac5b62c03811c7a58e0c96d59997106b3", null ],
      [ "e_Top", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a1a95cbc0e65199704e9669cdf71a659caa069c736ad2c68c2ffaa2a5706a5d1d8", null ]
    ] ],
    [ "EndingStyle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262", [
      [ "e_Square", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262ad369f0ab151a7d48ce125abcf33d4258", null ],
      [ "e_Circle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262aba4e027c19c6ab59bf389ed6c6a6d50e", null ],
      [ "e_Diamond", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262a8bce6447f89728810dbb5b18bc4ca243", null ],
      [ "e_OpenArrow", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262a6d4a571cda87b6bef6c7fd4731525947", null ],
      [ "e_ClosedArrow", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262a8223b0c332dbbb1b0c12dd100c943670", null ],
      [ "e_Butt", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262a67dd2e7eb41f25f6eb842d08856d8435", null ],
      [ "e_ROpenArrow", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262af76a8fed13f9785d876da48f797719e8", null ],
      [ "e_RClosedArrow", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262a7b879df93d84c3650299cdddeae59367", null ],
      [ "e_Slash", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262af2f17e36d694ff2ab5b3edf62d41eaad", null ],
      [ "e_None", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262ab799683e96ff7bb1b7d9e88ea56dd9e4", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a2196fee655e2e3cfb24ae4410a43e262acd8121a3ac95aa0a44e56c64436a1409", null ]
    ] ],
    [ "IntentType", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#accceb91e7367a063a861bc564726c00e", [
      [ "e_LineArrow", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#accceb91e7367a063a861bc564726c00ea155466fb7f32ad591e532287b59313d3", null ],
      [ "e_LineDimension", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#accceb91e7367a063a861bc564726c00eaceed7ab5aeb73d4596e605df21289d5f", null ],
      [ "e_null", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#accceb91e7367a063a861bc564726c00ea6b73d12c008fae09c0e93ba8c758937e", null ]
    ] ],
    [ "Line", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a32e3eb862777440ccebbae4f3fa949e6", null ],
    [ "Line", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#abab1f79bb34d21704cb700562e6c150e", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#ab8da1c8b0a5d2d9ccb45cb1b37a0744c", null ],
    [ "GetCaptionPosition", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#aa1f4468bdc82acb197fe0aaaf03784a6", null ],
    [ "GetEndPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a773d5f12cb9be0d06735d3c2215828ce", null ],
    [ "GetEndStyle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#aa609a678a8615f4c28990d551117f293", null ],
    [ "GetIntentType", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a3b4d74877e60b6cf76dfe37c5e598f76", null ],
    [ "GetLeaderLineExtensionLength", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#ae5de78e41394163cb88fc70635ae8373", null ],
    [ "GetLeaderLineLength", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a60738bb0488e8c3439fb2ea75b45a23c", null ],
    [ "GetLeaderLineOffset", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a9a028a8954677bdd8cea91aa34018899", null ],
    [ "GetShowCaption", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a40269917bbd99b37569794e505527a6c", null ],
    [ "GetStartPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a535d79863d7f3e9477c67efb37ef3e2f", null ],
    [ "GetStartStyle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#aa277eba0401db0f3b069d249e6e24b1e", null ],
    [ "GetTextHOffset", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a642dd9e7072ecda46b477a42faea4acc", null ],
    [ "GetTextVOffset", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#acf7ad72f50c116ba5303092093145588", null ],
    [ "SetCaptionPosition", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a8867c868f593f6ca2f7e281c97b8bee8", null ],
    [ "SetEndPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a020ed4ff953763ecca3e6b509704353e", null ],
    [ "SetEndStyle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a728bcdcfff1fcde8a834a02bf68abb81", null ],
    [ "SetIntentType", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a3d779b7d1921c5debb805ddaaa469c3d", null ],
    [ "SetLeaderLineExtensionLength", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a4f8c85198099fe896d6743100cfb1985", null ],
    [ "SetLeaderLineLength", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a36be1d5e88c38dd48d9443e257b36f64", null ],
    [ "SetLeaderLineOffset", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a60f5fc445a0ff93af1c1ce5cb79e179c", null ],
    [ "SetShowCaption", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#aaae9d44a2f54cb562f9cf84818b43a9e", null ],
    [ "SetStartPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a956586c40fc6e401b5f8e3d647e98d4d", null ],
    [ "SetStartStyle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#a366500aaf8f823f3b4f37fceae398f23", null ],
    [ "SetTextHOffset", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#af836da70640e9301a1ae6ad21c6d7408", null ],
    [ "SetTextVOffset", "classpdftron_1_1_p_d_f_1_1_annots_1_1_line.html#ab1c4534cf4d4a5bef8e711531a34a860", null ]
];