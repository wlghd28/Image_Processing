var classpdftron_1_1_p_d_f_1_1_trust_verification_result =
[
    [ "TrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#aec842a61c48a71f1e9c749ef62d4f7be", null ],
    [ "TrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#a81062f69fc7ee08bf3bedcf799a22dcb", null ],
    [ "~TrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#a3ce1e0a0432b816953f47b4f58981a6f", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#a5aa60efd0e8b274770211571b2d4bc5e", null ],
    [ "GetResultString", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#ac7da478f207f3511e978da9937a00a5b", null ],
    [ "GetTimeOfTrustVerification", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#a2ccf88c7a72d8fc018e698195cb6cea7", null ],
    [ "GetTimeOfTrustVerificationEnum", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#a2cecd3a63a0740ac0241fb06d9a2e29f", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#afa6e8465790d53c2df24020f12319e08", null ],
    [ "WasSuccessful", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#a5fecfc716b4ddb9179fb4f86f27fec0e", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_trust_verification_result.html#ac69b2e215357026e28cfc9d71e05a308", null ]
];