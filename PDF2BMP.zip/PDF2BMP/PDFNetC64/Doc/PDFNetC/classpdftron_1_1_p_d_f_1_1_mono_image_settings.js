var classpdftron_1_1_p_d_f_1_1_mono_image_settings =
[
    [ "CompressionMode", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a44a010ed7c1274c8f226fbfc0cc5dc84", [
      [ "e_jbig2", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a44a010ed7c1274c8f226fbfc0cc5dc84a53e9000cb54995ecb8b2000dfe1446d2", null ],
      [ "e_flate", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a44a010ed7c1274c8f226fbfc0cc5dc84ad53d108e7f7257841113d4354e8e115d", null ],
      [ "e_none", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a44a010ed7c1274c8f226fbfc0cc5dc84a0a98b6cccdfeb17659bc93fbe9002bba", null ]
    ] ],
    [ "DownsampleMode", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a02afc12ad6c8e99bb10a30eb225e30e0", [
      [ "e_off", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a02afc12ad6c8e99bb10a30eb225e30e0aa8b891d0f2366702e6332adb2c043e68", null ],
      [ "e_default", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a02afc12ad6c8e99bb10a30eb225e30e0aef9bd836838d3c3fc03aebb0f5586fcd", null ]
    ] ],
    [ "MonoImageSettings", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a33a105585bbf0babc3e7d9fe00ed9aae", null ],
    [ "ForceChanges", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#aad4325241d7704a5b732e22671280bba", null ],
    [ "ForceRecompression", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a35525412d459fb76b2144c348209d662", null ],
    [ "SetCompressionMode", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a552d227212a032c4d0086ad29ae361a1", null ],
    [ "SetDownsampleMode", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#ae0fbf2b0e21901113d5c5b9907aa8c97", null ],
    [ "SetImageDPI", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#a0a90bf9d86e3959ea7f0421944acd4a1", null ],
    [ "SetJBIG2Threshold", "classpdftron_1_1_p_d_f_1_1_mono_image_settings.html#aceb1e908b07c2936821502b3df1bfe31", null ]
];