var classpdftron_1_1_p_d_f_1_1_document_conversion =
[
    [ "Result", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a09a66942cd0b6e19c501e7c81e44f806", [
      [ "eSuccess", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a09a66942cd0b6e19c501e7c81e44f806ac4ee161ee1dfc17af233c7b1297fd506", null ],
      [ "eIncomplete", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a09a66942cd0b6e19c501e7c81e44f806ac438b36a3c9b926eccf2ef0b99c2e41c", null ],
      [ "eFailure", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a09a66942cd0b6e19c501e7c81e44f806adc6d7e7fa599b2b7a79d38c28e7c1c2b", null ]
    ] ],
    [ "DocumentConversion", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a3b09ed059eb1983c287c1076750c0b96", null ],
    [ "DocumentConversion", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#abef396dc3f48ccab1b6365bc38808c10", null ],
    [ "DocumentConversion", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a2d6f5c40b4c3a333cbaef6a9d1227d5f", null ],
    [ "~DocumentConversion", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#adb467284169d85a28e56ac43fe608543", null ],
    [ "CancelConversion", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a7dd1b9724db33c9fc543b018d4b53547", null ],
    [ "Convert", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a34ac0c0388171c3e4ebb7e60e151478d", null ],
    [ "ConvertNextPage", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#ab2fbed160d2b2f09d614404df6b92ccb", null ],
    [ "CreateInternal", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a9db499fa62f88531e85f413faf30cc5c", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a596f9b81c255d7a588004302cdf4edf5", null ],
    [ "GetConversionStatus", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a34024a63ca803bfd40fca668c8a37eaf", null ],
    [ "GetDoc", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a26aa969103406ef9c5c7384b7670a21d", null ],
    [ "GetErrorString", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#ab27bda426a6b05a01e1e14b09bb3af41", null ],
    [ "GetHandleInternal", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#ab7128837fd1b80a0fd24c770f3a1c6db", null ],
    [ "GetNumConvertedPages", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a18ee1262d49ac55bede622b10d2134f9", null ],
    [ "GetNumWarnings", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#aa81e240e22abf185d55b68fedfd511aa", null ],
    [ "GetProgress", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a3bd94c4b9d597b265064d834519ee9a2", null ],
    [ "GetProgressLabel", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#ac0c47d07173a0fa611613e4574e5d1ac", null ],
    [ "GetWarningString", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a10834bf11982a7a1ce753b5328aa7b45", null ],
    [ "HasProgressTracking", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a1cddd414c842cf267fc42343116a2630", null ],
    [ "IsCancelled", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a53cd8a2bafa5c068f9464ac2513e2b54", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a110881f92b6a9ea0c7d656cb5d823b9e", null ],
    [ "TryConvert", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#a1c96fa96cdefd98d8f4e2913570704d8", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_document_conversion.html#aad3527b1cee9c0ac4fb21ac008aebe3c", null ]
];