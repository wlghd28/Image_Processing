var classpdftron_1_1_p_d_f_1_1_struct_1_1_attr_obj =
[
    [ "AttrObj", "classpdftron_1_1_p_d_f_1_1_struct_1_1_attr_obj.html#ae43fe85fd08ffc2b30b06990d05d65c0", null ],
    [ "AttrObj", "classpdftron_1_1_p_d_f_1_1_struct_1_1_attr_obj.html#ab5001755e95d2b2808d789f7c1474df2", null ],
    [ "GetOwner", "classpdftron_1_1_p_d_f_1_1_struct_1_1_attr_obj.html#a4edd6b306c9ccf78b745552ebe2c5ef6", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_struct_1_1_attr_obj.html#a44055e5cde3c701b4fd0f3b47ac37bef", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_struct_1_1_attr_obj.html#ab07eff2f9dae5ff6989c79245dc0bd52", null ]
];