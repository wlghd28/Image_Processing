var classpdftron_1_1_p_d_f_1_1_annots_1_1_ink =
[
    [ "Ink", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#ac2f923849b39b4b760940f7c78f4388f", null ],
    [ "Ink", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#a9ed82f943673605a22ac726f05778710", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#ab11bbd098e8ee0f617e852a22f728a23", null ],
    [ "Erase", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#af61d6006ac61ae39e2924309d43bb7fc", null ],
    [ "GetHighlightIntent", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#ae107c7b95aeeb9d972f89d11101d838a", null ],
    [ "GetPathCount", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#adf745cb104ea4eed92f4802959a1b65b", null ],
    [ "GetPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#a5eddc5bfdc917c3dbd6316e23b16d3c4", null ],
    [ "GetPointCount", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#a3d65562ccf9dbf29e30f361e8711d68e", null ],
    [ "SetHighlightIntent", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#af362bff20890c9c1c7c10c0a8d50d574", null ],
    [ "SetPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_ink.html#ac63ec9c80855df106542de23641208ac", null ]
];