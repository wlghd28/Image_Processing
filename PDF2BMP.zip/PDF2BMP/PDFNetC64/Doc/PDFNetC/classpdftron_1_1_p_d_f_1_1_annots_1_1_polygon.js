var classpdftron_1_1_p_d_f_1_1_annots_1_1_polygon =
[
    [ "Polygon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_polygon.html#a26db3f0fe14f38978bf099d7eed8349f", null ],
    [ "Polygon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_polygon.html#aba2c1a9b94e8e88355d094420c19fd2d", null ],
    [ "Polygon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_polygon.html#ae911add55e8de860eca7ad1eb1838e02", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_polygon.html#a63439f0f96d9eca3b23f67ebe2b02560", null ]
];