var classpdftron_1_1_p_d_f_1_1_x_o_d_output_options =
[
    [ "AnnotationOutputFlag", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a0d2a5ad0510fdda6f9e5c7d180b0a306", [
      [ "e_internal_xfdf", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a0d2a5ad0510fdda6f9e5c7d180b0a306a8b641fb0723df10c23319fbfba0b2bc2", null ],
      [ "e_external_xfdf", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a0d2a5ad0510fdda6f9e5c7d180b0a306aa29535d15fe041c9c9f6832c8086f419", null ],
      [ "e_flatten", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a0d2a5ad0510fdda6f9e5c7d180b0a306a7d6020570da14cfc248cafe440c8a86c", null ]
    ] ],
    [ "SetAnnotationOutput", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a8202059f5fe2c789e0e71c181866dca5", null ],
    [ "SetElementLimit", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#abc3111d76c306d4b5a59a5e48e78fefb", null ],
    [ "SetEncryptPassword", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#af8f48175884a988b10fcc43768590e8e", null ],
    [ "SetExternalParts", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a1a061c77088e3621705cdfdc7d71db33", null ],
    [ "SetFlattenContent", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#acbaf39b849125f57e40d77955df13b90", null ],
    [ "SetFlattenThreshold", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#aaa25b30671727afe89bf365e8afb39fe", null ],
    [ "SetJPGQuality", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#ace47d35c3f9c345e9a4d63005b6555b3", null ],
    [ "SetMaximumImagePixels", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#ab7eefc0dbacd70e2c32ae2d555adf96f", null ],
    [ "SetOpacityMaskWorkaround", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#ad20e8877d70b38e2747dd7ceea6059f6", null ],
    [ "SetOutputThumbnails", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a8212a42014031d2e4c0c56821945bd14", null ],
    [ "SetPreferJPG", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a816e94d9833c4c12e04aa2e62d054b8b", null ],
    [ "SetSilverlightTextWorkaround", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a9babd3ea4da6c76994b354b595091a22", null ],
    [ "SetThumbnailSize", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a477f898ec8462db88ebe76670866fed5", null ],
    [ "SetThumbnailSize", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a123028da86e9b0e901c3ca7e7cd5f04f", null ],
    [ "UseSilverlightFlashCompatible", "classpdftron_1_1_p_d_f_1_1_x_o_d_output_options.html#a2f9ce03fb26d438dfeaf584f611e9693", null ]
];