var classpdftron_1_1_p_d_f_1_1_annots_1_1_strike_out =
[
    [ "StrikeOut", "classpdftron_1_1_p_d_f_1_1_annots_1_1_strike_out.html#ab42083d1c01751d20f62638c0c9e36dd", null ],
    [ "StrikeOut", "classpdftron_1_1_p_d_f_1_1_annots_1_1_strike_out.html#a5505bce2e0984be2390ce6e952d9547c", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_strike_out.html#a2cf9d11ef90b5dc1d2c26d044b4eaeca", null ]
];