var classpdftron_1_1_common_1_1_iterator_3_01int_01_4 =
[
    [ "Iterator", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#ab20b37dc87316f78a3499c34b76040d6", null ],
    [ "Iterator", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a543efff17a9b32235bd62e895af495ea", null ],
    [ "~Iterator", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a0e135cbd813d8b08a4c23e63d9fc9d56", null ],
    [ "Iterator", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a9b72a8d9cc0f662bf58aeb2ccd1b1564", null ],
    [ "Current", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a1d8c6535dedab3c6837a1e7adb025fb2", null ],
    [ "Destroy", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a2168faaa7150075f026ed6c4df581436", null ],
    [ "HasNext", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a6d429b010b7eaafcf0bed311fff92274", null ],
    [ "Next", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#aa8e5acc265eeea86f39d50bc91e97937", null ],
    [ "operator=", "classpdftron_1_1_common_1_1_iterator_3_01int_01_4.html#a057b74da0835d95aa82d675a022c1a76", null ]
];