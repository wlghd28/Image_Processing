var classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools =
[
    [ "LogBackend", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#af76368b331476bea5dd44f445c22a3f0", [
      [ "eDebugger", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#af76368b331476bea5dd44f445c22a3f0acc16f581d2f91e7ef83561467ead1eca", null ],
      [ "eDisk", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#af76368b331476bea5dd44f445c22a3f0aa3b63a1aa60fad4362ff99911d0888ee", null ],
      [ "eCallback", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#af76368b331476bea5dd44f445c22a3f0af58ed1094ffe63bad8465be1e57768d3", null ],
      [ "eConsole", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#af76368b331476bea5dd44f445c22a3f0a1557624ad9ff7247f441fc3818f87aaf", null ]
    ] ],
    [ "LogLevel", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7", [
      [ "eTrace", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7af4b9feaa6f5fc533e868d57ae8cda9e1", null ],
      [ "eDebug", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7a208c696dc8fc9cbdd18d0e82f620f0c0", null ],
      [ "eInfo", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7acd796309ee1edaf628d959cb164c9e45", null ],
      [ "eWarning", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7a5124e0f975d013737fe397d36bc3032e", null ],
      [ "eError", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7a5da8498b93e84361c69d4c53e74ab14c", null ],
      [ "eFatal", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7a9a453654a8b5c7f34656a54340774600", null ],
      [ "eDisabled", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#aaa166c4ed77afe94e2fccd4572faecf7a5404b42b416c9eacdd1707217de6f3d2", null ]
    ] ],
    [ "ConfigureLogFromJsonString", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a9b683f7693b2a341fba9f9b6fc8cbe58", null ],
    [ "DisableLogBackend", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a6509edb53cb1ed2a8cdb85e377b9f9f5", null ],
    [ "EnableLogBackend", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a18b6c7b3faba0e7499a3dc15205c6509", null ],
    [ "GetDefaultConfigFile", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#af6f96346c55a64217b5eea4f567469b1", null ],
    [ "GetPDFViewTileSummary", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a9b65dac4df9fcf5d49ddce5855a4a1fb", null ],
    [ "IsLogSystemAvailable", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a7f9681debf3e04df39ca3690025b166f", null ],
    [ "LogMessage", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a42b924975d37b132401eec4dc2614e3a", null ],
    [ "LogStreamMessage", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a6597652362fc666941dcb46a97e54566", null ],
    [ "SetCutoffLogThreshold", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a8501e6cee722909d43d7f4e065b56545", null ],
    [ "SetDefaultLogThreshold", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a40ebcec2a5a2ef895cf6ae74c2284040", null ],
    [ "SetLogFileName", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a801229286bec3618d3552f3a97d7bf21", null ],
    [ "SetLogLocation", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#a847f898a85a7525e89fd2f31765f4a6d", null ],
    [ "SetThresholdForLogStream", "classpdftron_1_1_p_d_f_1_1_p_d_f_net_internal_tools.html#ada548d189c48b1943fdb5f61b9ad8935", null ]
];