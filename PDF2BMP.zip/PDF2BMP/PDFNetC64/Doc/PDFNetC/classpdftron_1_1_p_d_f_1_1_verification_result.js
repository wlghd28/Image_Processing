var classpdftron_1_1_p_d_f_1_1_verification_result =
[
    [ "DisallowedChange", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a5440128d9e4de0056c0fe264c9388729", null ],
    [ "DigestStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5a", [
      [ "e_digest_invalid", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5aa33ae7acb782d8bcbbf3dc9335d840402", null ],
      [ "e_digest_verified", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5aad22c80f396b7d7778c09a2af0e745b1d", null ],
      [ "e_digest_verification_disabled", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5aa2cb6de9c49975b61059a82cba02f3fb2", null ],
      [ "e_weak_digest_algorithm_but_digest_verifiable", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5aa28e47723a47571b4723c8388dcc1e0cf", null ],
      [ "e_no_digest_status", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5aa3f8a8af06b8b19207c675095ca7ee08c", null ],
      [ "e_unsupported_encoding", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a430fc4d16f5403d6c8f671208aa28e5aa148a90321060a52e36e945b6edbf1f2d", null ]
    ] ],
    [ "DocumentStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ae473caa85729f6a0f9c9eddbb9df1e94", [
      [ "e_no_error", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ae473caa85729f6a0f9c9eddbb9df1e94acd9c1ad8872e033ba842a69f4df721b3", null ],
      [ "e_corrupt_file", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ae473caa85729f6a0f9c9eddbb9df1e94a1c1a53205b088e5128e4831c1db426e2", null ],
      [ "e_unsigned", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ae473caa85729f6a0f9c9eddbb9df1e94ac7e8d7e004a68d0056191e1ea8c8e6fd", null ],
      [ "e_bad_byteranges", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ae473caa85729f6a0f9c9eddbb9df1e94afadaff39881fc19e7a31a03d3d30ae52", null ],
      [ "e_corrupt_cryptographic_contents", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ae473caa85729f6a0f9c9eddbb9df1e94a60b42e881718bbaff9cdb60dae98915c", null ]
    ] ],
    [ "ModificationPermissionsStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a2c8eff40232a7b3a122f166ca0e4b693", [
      [ "e_invalidated_by_disallowed_changes", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a2c8eff40232a7b3a122f166ca0e4b693a2aad470a23a6650932e5b4afc182fe0f", null ],
      [ "e_has_allowed_changes", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a2c8eff40232a7b3a122f166ca0e4b693ae4556570665edf4bf3c0b99c80861365", null ],
      [ "e_unmodified", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a2c8eff40232a7b3a122f166ca0e4b693a14161c7970b003b0902518c167d24256", null ],
      [ "e_permissions_verification_disabled", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a2c8eff40232a7b3a122f166ca0e4b693ace0077152511be9fac1c336f186dc148", null ],
      [ "e_no_permissions_status", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a2c8eff40232a7b3a122f166ca0e4b693a7efc81b0feb106a8e0dc563f4401d895", null ]
    ] ],
    [ "TrustStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aa8ef0d3a456120ef94b172a02d762b1d", [
      [ "e_trust_verified", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aa8ef0d3a456120ef94b172a02d762b1da0e2be4929f9e788d11dfdc8fdac6d4c5", null ],
      [ "e_untrusted", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aa8ef0d3a456120ef94b172a02d762b1da7e82e76452fcfe2a9fbf917ab568be49", null ],
      [ "e_trust_verification_disabled", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aa8ef0d3a456120ef94b172a02d762b1daa31c834f5c3223f1e85eba18e6014066", null ],
      [ "e_no_trust_status", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aa8ef0d3a456120ef94b172a02d762b1da09e884952f57aa8afefa5a3fd548b8df", null ]
    ] ],
    [ "VerificationResult", "classpdftron_1_1_p_d_f_1_1_verification_result.html#ab45c410b3b0c9e46c8320a3e12f9f1d4", null ],
    [ "VerificationResult", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a9e9b5bd54bd4c4dbfa4e616809eec2e0", null ],
    [ "~VerificationResult", "classpdftron_1_1_p_d_f_1_1_verification_result.html#af9f566abf33a444ba8d90fb423bac267", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a6762cbdfba397297790b0e3cd7fbde7f", null ],
    [ "GetDigestStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a69fd2cf2e9bbdb05aea4aad69a8c5903", null ],
    [ "GetDisallowedChanges", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a84137a7fce07e985ccfb8aa36c24ce8b", null ],
    [ "GetDocumentStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aceb515e3ec7dc963359b2f3231f5231b", null ],
    [ "GetPermissionsStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a9bb173a5bcbc0d2f755950b90c80ea07", null ],
    [ "GetSignersDigestAlgorithm", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a6c3b086af92166df097f11de0d95db7a", null ],
    [ "GetTrustStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a254ae2047dd844f84cb7c21624917473", null ],
    [ "GetTrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a8e178bfefce50c6e0cf2f6f58f0d261e", null ],
    [ "GetVerificationStatus", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a728a092f7b50c4259a18669fc23960a8", null ],
    [ "HasTrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_verification_result.html#a1661f3688e0b05079ade92ab2de772ad", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aa20bac7ca6d3e1e82d26fc2518c706f3", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_verification_result.html#aed95b48a8808dd7d1567f17a2053ade9", null ]
];