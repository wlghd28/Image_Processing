var classpdftron_1_1_p_d_f_1_1_geometry_collection =
[
    [ "SnappingMode", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a63744e7f73c1a34a38b843b5f55743d7", [
      [ "eDefaultSnapMode", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a63744e7f73c1a34a38b843b5f55743d7a6184bb36ecf7b23bbe83d3a89af575ac", null ],
      [ "ePointOnLine", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a63744e7f73c1a34a38b843b5f55743d7a249fd55e6e43ec8db77c50ddf70303e2", null ],
      [ "eLineMidpoint", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a63744e7f73c1a34a38b843b5f55743d7ab02d44db2e07a44d8cfe168e7f6c9274", null ],
      [ "eLineIntersection", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a63744e7f73c1a34a38b843b5f55743d7a7f421e9f2e65f51e1cd30924f9ca6636", null ],
      [ "ePathEndpoint", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a63744e7f73c1a34a38b843b5f55743d7ac6cb3d4e7509a56ee9f3285a71ef8830", null ]
    ] ],
    [ "GeometryCollection", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a8c597f3561a7df19b1b16b75e7655e4f", null ],
    [ "GeometryCollection", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#ac923c48f3cc6c4a7c11149eb83a7bf38", null ],
    [ "GeometryCollection", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#abc8efce6af755cc5e27489b28421ee85", null ],
    [ "~GeometryCollection", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#ae18412f2071b5c671cf1700f501582f2", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#adf23d63bc75441c80b8808b29d3308d7", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a55d49c1dfb07983d29ee7416128d37d8", null ],
    [ "SnapToNearest", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#ae359a19239f302834d8122e366d11fd4", null ],
    [ "SnapToNearestPixel", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a1762147926f4774a756132d264cbd380", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_geometry_collection.html#a99fb8e1430d357d0710e539797f02906", null ]
];