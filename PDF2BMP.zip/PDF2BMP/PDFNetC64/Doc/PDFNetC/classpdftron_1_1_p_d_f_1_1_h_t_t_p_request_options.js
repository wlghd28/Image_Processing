var classpdftron_1_1_p_d_f_1_1_h_t_t_p_request_options =
[
    [ "HTTPRequestOptions", "classpdftron_1_1_p_d_f_1_1_h_t_t_p_request_options.html#ac74a8f97b75308710eb6f8821db880a2", null ],
    [ "AddHeader", "classpdftron_1_1_p_d_f_1_1_h_t_t_p_request_options.html#a71e6d5e8179531bee72db1958af43588", null ],
    [ "PDF::PDFViewCtrl", "classpdftron_1_1_p_d_f_1_1_h_t_t_p_request_options.html#a75c1873411f4c1c0210d5cf49d2f8bbc", null ],
    [ "m_obj", "classpdftron_1_1_p_d_f_1_1_h_t_t_p_request_options.html#a7c7d563fc40d848bea9eafeda8e6d205", null ],
    [ "m_objset", "classpdftron_1_1_p_d_f_1_1_h_t_t_p_request_options.html#a70911b22bf0dcae181d2576aaf516009", null ]
];