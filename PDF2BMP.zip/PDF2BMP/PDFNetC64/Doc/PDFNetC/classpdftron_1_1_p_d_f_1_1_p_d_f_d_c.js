var classpdftron_1_1_p_d_f_1_1_p_d_f_d_c =
[
    [ "PDFDC", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c.html#ae252603f9ff8d5fd09f22f2378c898e3", null ],
    [ "~PDFDC", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c.html#a785074092fac6dbf27eb5119b8b82e0e", null ],
    [ "Begin", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c.html#a8693e9b9d9b88941113375033483af6e", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c.html#ab088d65e13579fd5307b42baba6b6bba", null ],
    [ "End", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c.html#a5a0dafd867767b20463b9794c4e80a1d", null ],
    [ "SetDPI", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c.html#a4b4cacb2a779210370937a6a2263b846", null ]
];