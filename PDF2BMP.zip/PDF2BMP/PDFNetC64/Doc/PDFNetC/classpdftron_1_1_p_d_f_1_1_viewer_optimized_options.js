var classpdftron_1_1_p_d_f_1_1_viewer_optimized_options =
[
    [ "ViewerOptimizedOptions", "classpdftron_1_1_p_d_f_1_1_viewer_optimized_options.html#a50f4cf8c9b97233d6b7f3dfee1e2bde5", null ],
    [ "SetOverprint", "classpdftron_1_1_p_d_f_1_1_viewer_optimized_options.html#a958761300fc069f796c573d81c74e7a6", null ],
    [ "SetThumbnailRenderingThreshold", "classpdftron_1_1_p_d_f_1_1_viewer_optimized_options.html#a51fcd4c45a764d0b75604672d6e53b56", null ],
    [ "SetThumbnailSize", "classpdftron_1_1_p_d_f_1_1_viewer_optimized_options.html#acf423f97081a0feb0439180bde5430fc", null ]
];